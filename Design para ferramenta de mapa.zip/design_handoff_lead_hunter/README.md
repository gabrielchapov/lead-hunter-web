# Handoff: Lead Hunter — prospecting tool for local businesses without a website

## Overview
Lead Hunter is an interactive prospecting tool (in **Portuguese, pt-BR**) that helps a solo founder find local businesses that don't yet have a website, so they can pitch them a service. It combines a real map, a filterable/sortable lead list, a Kanban pipeline, a stats dashboard, and a WhatsApp message-template editor. Copy tone is "lead hunter" — direct, action-oriented.

## About the Design Files
The files in this bundle are **design references created in HTML** — a working prototype showing the intended look and behavior. They are **not production code to copy directly**. The task is to **recreate these designs in the target codebase's existing environment** (React, Vue, SwiftUI, native, etc.), following its established patterns, component library, and state conventions. If no environment exists yet, choose the most appropriate stack (a React + Leaflet SPA is a natural fit) and implement there.

The prototype is built as a single "Design Component" HTML file that uses a bound design system's stylesheet for tokens. Read it for exact structure, but re-implement idiomatically.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, layout, and interactions are all specified. Recreate the UI closely using the codebase's own libraries. The map, filters, sorting, exports, Kanban moves, enrichment simulation, and template preview are all functional in the prototype.

## Tech used in the prototype (suggested real equivalents)
- **Map**: Leaflet 1.9.4 + **CARTO dark_all** raster tiles (`https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png`, subdomains `abcd`), OpenStreetMap data. Use `react-leaflet` or Leaflet directly. Markers are `L.circleMarker`. A `L.circle` shows the search radius.
- **Design system**: "Modernist" — flat, architectural, Archivo typeface, 0 border-radius, strong 2px rules, labels flush-left. **Overridden to a dark theme** (see Design Tokens).
- **Distance**: Haversine, client-side, km.
- **Export**: CSV (UTF-8 BOM + quoted fields) and Excel (HTML `<table>` served as `application/vnd.ms-excel`) via Blob download.

## Screens / Views
Single-page app with a top nav switching four views: **Mapa**, **Kanban**, **Painel**, **Mensagens**. Global export (CSV/Excel) lives in the nav, right-aligned.

### Top navigation (persistent)
- Height 56px, bottom border 2px `--color-divider`. Left: 22×22px solid accent square + brand "Lead Hunter" (Archivo 800, 19px) + tagline "o radar de negócios sem site" (11px, neutral-600).
- Tabs: Mapa / Kanban / Painel / Mensagens. Active tab = accent text + 3px accent bottom border; inactive = text color, transparent border. Labels Archivo 800, 14px.
- Right: "Exportar" label + two secondary buttons "CSV" and "Excel".

### 1. Mapa (primary)
Map-first layout: full-bleed map fills the content area with floating panels over it.
- **Map** fills the whole content region (`position:absolute; inset:0`). Hidden with `display:none` when another view is active (re-run Leaflet `invalidateSize()` on return).
- **Floating search card** — top-left, 298px wide, `--color-surface` fill, 2px `--color-text` border, `--shadow-lg`, 16px padding, 12px gap. Contains:
  - Categoria — `<select>`: "Todas as categorias", Clínica médica, Odontologia, Estética, Fisioterapia, Veterinária.
  - Localização — text input, default "Porto Alegre, Rio Grande do Sul".
  - Raio — range slider 2–40 km (default 20), label shows "{n} km" in accent on the right.
  - Primary button, full-width, flush-left label: "◎ Buscar leads sem site" (→ "Buscando…" ~800ms while searching).
  - Footer line: "**{n}** sem site no raio · **{n}** enriquecidos".
- **Legend + nothing else** — bottom-left panel, `--color-surface`, 2px border, `--shadow-md`: three dots Quente (blue) / Morno (amber) / Frio (gray).
- **Results drawer** — right edge, 340px wide, `--color-surface`, 2px left border `--color-text`, full height, flex column:
  - Header: "{n} leads" (Archivo 800, 16px) + "sem site". Channel filter chips: WhatsApp / Instagram / E-mail (toggle; on = accent fill + white text, off = transparent + divider border). Sort `<select>`: Relevância (score) / Distância / Nome (A–Z). Checkbox "Incluir quem já tem site".
  - Scrolling list of **lead cards** (see component below).
  - Footer: full-width primary button "⚡ Modo disparo ({n})" — n = hot leads with WhatsApp.

#### Lead card (drawer)
- 1px `--color-divider` border (accent border + inset 3px accent left bar when selected), `--color-surface` bg, 11–12px padding, clickable (selects → enlarges its map marker).
- Row 1: left = name (Archivo 800, 14px) + address (11px, neutral-700); right = temperature tag + score number (Archivo 800, 15px; accent if ≥60 else neutral-700).
- Contact line (11px, neutral-700): first available of phone/insta/email, or "sem contato — enriqueça", or "buscando contatos…" while enriching.
- Actions row: primary "WhatsApp" + secondary "Detalhes" + secondary "Enriquecer" (→ "…" while loading → "✓ Enriquecido").

### 2. Kanban
Four equal columns separated by 2px rules, inside a 2px `--color-text` border. Columns: **Novo → Contatado → Respondeu → Fechado**. Column header: name (Archivo 800, 12px, uppercase, letter-spacing .06em) + count (accent). Cards show name, category, temperature tag with score, and ‹ › buttons to move the lead between adjacent stages (disabled at ends). Respects the Categoria filter and "incluir quem tem site".

### 3. Painel (dashboard)
Padding 28–32px. Title "Painel" + subtitle "{location} · raio {n} km · categoria {category}".
- Stat row: 4 cells, each 2px `--color-text` border. Big number (Archivo 800, 38px, accent) + uppercase label (10px, neutral-600): "Sem site no raio", "Leads quentes", "Enriquecidos", "Com WhatsApp".
- Two-column charts: "Por categoria" (horizontal bars, accent fill, count) and "Temperatura dos leads" (Quente=accent blue, Morno=amber, Frio=neutral-500). Bar track is neutral-200, height 12px, width = proportion of max.

### 4. Mensagens (WhatsApp template editor)
Two columns (1fr / 380px), max-width 980px.
- Left: variable-insert buttons (+ nome, + categoria, + bairro), a textarea (min-height 220px, 14px, line-height 1.6) holding the template, a primary "Salvar modelo" (→ "✓ Salvo" ~1.6s) and a note "Disparo atinge **{n}** leads quentes com WhatsApp".
- Right: "Prévia" — a WhatsApp-style chat mock (beige `#e7ded4` panel, 2px border; white bubble, dark text, 280px max) rendering the template filled for the first visible lead. Caption "Exemplo com **{name}**".
- Default template: `Olá! Vi que a {{categoria}} {{nome}} no bairro {{bairro}} ainda não tem um site. Ajudo negócios locais a captar clientes com um site feito por IA em 48h. Posso te mostrar um exemplo rápido?`
- Variables: `{{nome}}`, `{{categoria}}` (lowercased), `{{bairro}}` (parsed as the text after "·" in the address).

### Details dialog (modal, from any "Detalhes")
Backdrop + centered dialog (max 440px). Title = lead name + temperature tag with score. Body: rows for Categoria, Endereço, Telefone, Instagram, E-mail, Site (each "—" if missing), separated by 1px divider rules. Actions: secondary "Fechar" + primary "Abrir WhatsApp".

## Interactions & Behavior
- **Filtering (live, recomputed on every change)**: exclude sites unless "incluir" checked; match category (unless "Todas"); if any channel chip active, keep leads matching at least one active channel; keep only leads within `radius` km of center (Haversine). Sort by score desc / distance asc / name.
- **Map**: recompute markers on every relevant state change; radius circle updates with the slider; clicking a marker selects the lead (bigger marker, tooltip "name / category · score"); clicking a card selects and can pan. "Buscar" fits map bounds to the radius circle after ~800ms.
- **WhatsApp action**: opens `https://wa.me/{digits}?text={encoded filled template}` in a new tab (falls back to `wa.me/?text=` if no number).
- **Enriquecer**: ~1.3s simulated lookup, then fills phone/insta/email and flips all channel flags true + marks enriched. In a real build, wire to your enrichment API.
- **Kanban move**: shifts stage index ±1, clamped.
- **Modo disparo**: prototype shows an `alert()` summarizing how many hot WhatsApp leads would receive the current template. Replace with the real bulk-send flow.
- **Export**: CSV/Excel download the currently-filtered leads (columns: Nome, Categoria, Endereço, Telefone, Instagram, E-mail, Score, Temperatura).

## State Management
- `view`: "mapa" | "kanban" | "painel" | "mensagens"
- `category` (string), `location` (string), `radius` (2–40), `sortBy` ("score"|"distancia"|"nome")
- `channels`: { wa, ig, em } booleans; `includeSite` boolean
- `searching`, `saved` (transient UI flags)
- `selectedId`, `dialogId` (nullable lead ids)
- `template` (string)
- `leads[]`: { id, name, category, address, score, wa, ig, em, hasSite, lat, lng, stage, enriched, enriching, phone, insta, email }
- Derived (not stored): visible/filtered list, counts, chart bars, drawer view-models.
- Map objects (Leaflet map, radius circle, marker layer) held outside reactive state.

## Design Tokens (dark theme — blue primary, amber secondary)
Base is the Modernist system with a dark override. Font: **Archivo** (headings & body), weights 400/800. Radius: **0** everywhere. Rules/borders: **2px**. Button labels **flush-left**.

Colors:
- bg `#0e131b` · surface `#161d28` / `#1c2532` · text `#e7ecf3` · divider `#2a3441`
- Accent (blue) ramp: base `#4d8bff`; 100 `#15233d`, 200 `#1c2f52`, 400 `#6ea3ff`, 600 `#3b78f0`, 700 `#a9c6ff`, 800 `#c6d9ff`, 900 `#e6f0ff`
- Neutral ramp (inverted: 100 darkest → 900 lightest): 100 `#1a212c`, 200 `#222b37`, 300 `#2f3a47`, 400 `#465262`, 500 `#6a7683`, 600 `#8b95a2`, 700 `#a8b1bd`, 800 `#c6ccd5`, 900 `#e7ecf3`
- Secondary (amber): `#f0a742`; tag bg `#33260f`, tag text `#f3c583`
- Temperature: Quente = accent blue `#4d8bff` (score ≥60), Morno = amber `#f0a742` (45–59), Frio = neutral `#6a7683` (<45)
- Shadows: sm `0 1px 2px rgba(0,0,0,.5)`, md `0 3px 10px rgba(0,0,0,.55)`, lg `0 8px 28px rgba(0,0,0,.6)`

Spacing: 8px rhythm; panel padding 11–16px; view padding 28–32px.

## Assets
- Map tiles: CARTO dark basemap (attribution "© OpenStreetMap © CARTO").
- Icons: prototype uses text glyphs (◎, ⚡, ‹ ›). The Modernist system specifies **Lucide** icons — use Lucide in the real build (e.g. `crosshair`, `zap`, `chevron-left/right`, `search`, `download`).
- No image assets. Lead data is fictional (28 businesses around Porto Alegre) — replace with real data / API.

## Files
- `Lead Hunter.dc.html` — the full interactive prototype (all four views + dialog).
- `Lead Hunter - wireframes.dc.html` — the three explored layout directions for the Mapa screen (1a left rail, 1b top bar, 1c map-first — 1c was chosen).
- `styles.css` — the Modernist design-system token + component stylesheet the prototype links (tokens are overridden to the dark theme inline in the prototype's `<style>`).

> Note: the `.dc.html` files use a lightweight in-house template runtime. Read them for structure and exact values; re-implement in your framework rather than porting the runtime.
